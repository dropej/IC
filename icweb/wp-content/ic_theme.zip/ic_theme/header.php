<!DOCTYPE html>
<html <?php language_attributes(); ?> ng-app="myapp">
<head>
  <title>My AngularJS Theme</title>
  <?php wp_head();?>
</head>
<body>